//
// Bmp.cc
//
// Copyright (c) 2013 ZhangYuanwei <zhangyuanwei1988@gmail.com>

#include "Image.h"

#ifdef HAVE_BMP

DECODER_FN(Bmp){
//TODO
return FAIL;
}

ENCODER_FN(Bmp){
//TODO
return FAIL;
}

#endif
